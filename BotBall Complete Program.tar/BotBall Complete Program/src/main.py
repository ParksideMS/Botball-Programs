#!/usr/bin/python
import os, sys
import ctypes
M=ctypes.CDLL("/usr/lib/libkipr.so")

def main():
    
    M.create_connect()
    M.enable_servos()
    Distance = M.get_create_distance
    Distance = 0
    Cheese = 0
    
    while 100 > Distance:
        M.create_drive_direct(50,50)
        M.msleep(100)
        Distance = M.get_create_distance()
    
    print Distance
    M.create_drive_direct(-50,50)
    M.msleep(2000)
    M.create_drive_direct(0,0)
    Distance = 0
            
    while 70 > Distance:
        M.create_drive_direct(50,50)
        M.msleep(100)
    
    print Distance
    Distance = 0
    M.create_drive_direct(-50,50)
    M.msleep(2000)
    M.create_drive_direct(0,0)
    M.msleep(100)
            
    Time = 0        
    M.camera_open()
    M.camera_update()
    print 'there are this many orange objects: ', M.get_object_count(0)
    print 'there are this many blue objects: ', M.get_object_count(1)
    while 5 > Time:
        M.camera_update()
        Time + 1
        pos = M.get_object_center_x(0,0)
        print pos
        M.msleep(10)
        if pos > 80:
            M.create_drive_direct(50,-50)
            M.msleep(100)
        else:
            M.create_drive_direct(-50,50)
            M.msleep(100)
    
    Distance = 0
    while 75 > Distance:
        Distance = M.get_create_distance
        M.create_drive_direct(50,50)
        M.msleep(100)
    
    M.set_servo_position(1,0000000000000001)
    M.create_drive_direct(50,-50)
    M.msleep(2000)
    Distance = 0
    
    while 50 > Distance:
        M.create_drive_direct(0,0)
        M.msleep(2000)
        
    M.create_drive_direct(50,-50)
    M.msleep(2000)
            
    Distance = 0
    while 75 > Distance:
        M.create_drive_direct(50,50)
        M.msleep(100)
    
    M.create_drive_direct(50,-50)
    M.msleep(500)
            
    M.motor(1,50)
    M.msleep(5000)
            
    M.create_drive_direct(-50,50)
    M.msleep(1000)
            
    M.set_servo_position(1,000000000000000000000000000000000001)
            
    M.create_drive_direct(50,-50)
    M.msleep(2000)
   
    Minecarts == 0
    
    while Minecarts <= 4:
        M.create_drive_direct(50,50)
        M.msleep(1000)
        Minecarts + 1
        
        M.create_drive_direct(-50,50)
        
        M.set_servo_position(1,0000000000000000000000000000000001)
        M.create_drive_direct(50,50)
        M.msleep(500)
            
        M.set_servo_position(1,0000000000000000000000000000000001)
            
        M.create_drive_direct(-50,-50)
        M.msleep(500)
            
        M.set_servo_postition(1,000000000000000000000000000000001)
        
        M.create_drive_direct(50,-50)
        M.msleep(3000)
        
            
            
    M.create_drive_direct(50,-50)
    M.msleep(1000)
            
    M.create_drive_direct(50,50)
    M.msleep(5000)
            
    M.create_drive_direct(50,-50)
    M.msleep(1000)
            
    M.create_drive_direct(50,50)
    M.msleep(1000)
        
            
    
        
        
if __name__== "__main__":
    sys.stdout = os.fdopen(sys.stdout.fileno(),"w",0)
    main();
